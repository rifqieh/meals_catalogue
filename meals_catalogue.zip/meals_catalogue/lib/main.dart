import 'package:flutter/material.dart';
import 'model/meal.dart';
import 'view/detail.dart';
import 'api_service.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MealsCataloguePage(),
    );
  }
}

class MealsCataloguePage extends StatefulWidget {
  MealsCataloguePage({Key key}) : super(key: key);
  @override
  _MealsCataloguePageState createState() => _MealsCataloguePageState();
}

class _MealsCataloguePageState extends State<MealsCataloguePage> {
  List idDessert;
  List idSeafood;
  List<Meal> dessert = [];
  List<Meal> seafood = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    loadData();
  }

  loadData() async {
    List<Meal> des = await getData('dessert');
    List<Meal> sea = await getData('seafood');
    setState(() {
      dessert = des;
      seafood = sea;
    });
  }

  getBody(int section) {
    if (dessert.length == 0 && seafood.length == 0) {
      return Center(
        child: CircularProgressIndicator(),
      );
    } else {
      return getGridView(section);
    }
  }

  GridView getGridView(int section) {
    List<Meal> meals = (section == 0) ? dessert : seafood;
    return GridView.builder(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      padding: EdgeInsets.all(10),
      itemCount: meals.length,
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          child: GridTile(
            child: Container(
              child: Hero(
                  tag: '${meals[index].idMeal}',
                  child: Image.network('${meals[index].strMealThumb}')),
            ),
            footer: GridTileBar(
              backgroundColor: Colors.black54,
              title: Text(meals[index].strMeal),
            ),
          ),
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => MealDetailPage(
                        meal: meals[index], index: meals[index].idMeal)));
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Meals Catalogue'),
          bottom: TabBar(
            tabs: <Widget>[
              Tab(text: 'Dessert'),
              Tab(text: 'Seafood'),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            getBody(0),
            getBody(1),
          ],
        ),
      ),
    );
  }
}
