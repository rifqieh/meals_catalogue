List<String> gambarBreakfast = [
  'http://www.dapurkobe.co.id/wp-content/uploads/bakwan-sayur-gandum.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/sawi-putih-bakso.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/nasi-tepeng.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/telur-dadar-serundeng.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/karedok.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/tahu-teriyaki.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/pisang-meler.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/bola-makaroni-jagung.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/sate-telur-puyuh.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/bakso-ayam-kecap.jpg'
];

List<String> gambarDessert = [
  'http://www.dapurkobe.co.id/wp-content/uploads/pisang-meler.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/pie-buah.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/pisang-gapit.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/apel-pie-goreng.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/nagasari-labu.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/apem-pandan.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/tomat-telur-panggang.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/ubi-goreng-kismis.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/salad-pepaya.jpg',
  'http://www.dapurkobe.co.id/wp-content/uploads/srikaya-roti-tawar.jpg'
];
