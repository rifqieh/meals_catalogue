//List<String> namaBreakfast = [
//  'Rendang paha ayam organik',
//  'Gulai ayam',
//  'Indomie seblak macaroni',
//  'Penyetan sambel terasi udang',
//  'Tumis jamur tiram',
//  'Capcay goreng',
//  'Oseng kacang panjang',
//  'Cumi pedas manis',
//  'Pesmol ikan nila',
//  'Cumi sambal hijau'
//];

List<String> namaBreakfast = [
  'Bakwan Sayur Gandum',
  'Sawi Putih Bakso',
  'Nasi Tepeng',
  'Telur Dadar Serundeng',
  'Karedok',
  'Tahu Teriyaki',
  'Pisang Meler',
  'Bola Makaroni Jagung',
  'Sate Telur Puyuh',
  'Bakso Ayam Kecap'
];

List<String> namaDessert = [
  'Pisang Meler',
  'Pie Buah',
  'Pisang Gapit',
  'Apel Pie Goreng',
  'Nagasari Labu',
  'Apem Pandan',
  'Tomat Telur Panggang',
  'Ubi Goreng Kismis',
  'Salad Pepaya',
  'Srikaya Roti Tawar'
];
