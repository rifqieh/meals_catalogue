import 'package:flutter/material.dart';
import 'package:meals_catalogue/model/meal.dart';

class MealDetailPage extends StatelessWidget {
  final Meal meal;
  final String index;

  MealDetailPage({Key key, this.meal, this.index}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${meal.strMeal}'),
      ),
      body: ListView(
        children: <Widget>[
          Hero(
            tag: '${meal.idMeal}',
            child: Image.network('${meal.strMealThumb}'),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 20, bottom: 10),
              child: Text(
                '${meal.strMeal}',
                style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.w500),
              ),
            ),
          ),
          Container(
              padding: EdgeInsets.only(top: 10, left: 10, right: 10),
              child: Text('Category: ${meal.strCategory}')),
          Container(
              padding: EdgeInsets.only(top: 10, left: 10, right: 10),
              child: Text('Area: ${meal.strArea}')),
          Container(
              padding:
                  EdgeInsets.only(top: 10, left: 10, right: 10, bottom: 20),
              child: Text('Instruction: \n${meal.strInstructions}')),
        ],
      ),
    );
  }
}
